class Message 
{
	public Dancer dancer;
	public int dance_number;

	public Message(Dancer d, int n)
	{
		this.dancer = d;
		this.dance_number = n;
	}
}